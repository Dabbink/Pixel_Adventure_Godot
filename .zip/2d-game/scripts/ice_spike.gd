extends Area2D


func _ready() -> void:
	monitoring = true
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	print("Ice spike hit: ", body.name)
	if body.is_in_group("player") and body.alive:
		body.die()
